import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'home-component',
    templateUrl: './employee-detail.component.html'
})

export class EmployeeDetailComponent {
    constructor (private router: Router){
        
    }

    GoToEmployee() {
        this.router.navigate(['employees']);
    }
}