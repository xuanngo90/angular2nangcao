import { Component } from '@angular/core';

@Component({
  selector: 'main-content',
  template: `
		<h2>Subtitle</h2>
  `
})
export class AppSampleContent {
  
}