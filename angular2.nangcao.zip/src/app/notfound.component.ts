import {Component} from '@angular/core';

@Component({
    selector: 'not-found-component',
    template: `
        <h4>404 Error</h4>
    `
})

export class NotFoundComponent {

}